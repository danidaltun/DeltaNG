# دلتا ان‌جی — رابط سرورها (نسخه بهینه‌شده ۲)

این پروژه نسخه بهینه‌شده و تمیز صفحه سرورهای اپلیکیشن **دلتا ان‌جی** است.

## تغییرات و بهینه‌سازی‌ها

- تمام متن‌های فارسی خراب‌شده (`?????`) اصلاح و بازنویسی شد.
- کد HTML/CSS/JS تمیزتر، سبک‌تر و خواناتر شد.
- کلاس‌های تکراری و استایل‌های غیرضروری حذف شدند.
- عملکرد فیلتر، جستجو و پینگ بهبود یافت.
- پشتیبانی بهتر از safe-area (نچ و gesture navigation).
- دسترسی‌پذیری (aria-label) اضافه شد.
- آماده برای قرارگیری داخل WebView اندروید.
- بخش «اشتراک» از ناوبری پایین حذف شد.

## بهینه‌سازی‌های نسخه ۲

- **حذف Tailwind CDN:** اسکریپت runtime حدود ۳۰۰ کیلوبایتی حذف شد. فقط CSSِ کلاس‌های استفاده‌شده (مینیفای‌شده) داخل صفحه قرار گرفت، پس صفحه بدون اینترنت هم رندر می‌شود.
- **حذف Google Fonts:** هم Material Symbols و هم فونت‌های لاتین حذف شدند. آیکون‌ها ۱۷ SVG درون‌صفحه‌ای (sprite) هستند و فونت از فونت‌های سیستم می‌آید.
- **افکت‌های سبک‌تر:** `blur-3xl` با گرادیان شعاعی، `backdrop-blur-xl` با `md` و `will-change` حذف شد. `min-height: 884px` ثابت هم به `100dvh` تبدیل شد.
- **JS سبک‌تر:** با event delegation بازنویسی شد و برای کاربرانی که انیمیشن را خاموش کرده‌اند، `prefers-reduced-motion` رعایت می‌شود.
- **چیدمان:** اسم سرور دیگر با «…» بریده نمی‌شود، متن‌های کوچک وسط عبارت نمی‌شکنند و ترتیب «ms» در RTL درست شد.
- **دسترسی‌پذیری:** `user-scalable=no` حذف شد تا زوم کار کند.
- **لوگو:** هنوز از آدرس راه دور Google بارگذاری می‌شود. اگر باز نشود، یک آیکون inline جایگزین نمایش داده می‌شود. برای نسخهٔ نهایی فایل لوگو را داخل پروژه بگذارید.

> **نیازمندی:** CSS خروجی Tailwind نسخه ۴ است و به Chrome/WebView نسخه ۹۹ یا بالاتر نیاز دارد.

## ساختار

```
delta-vpn-app/
├── www/
│   └── index.html          ← فایل اصلی رابط کاربری
├── android-stub/           ← راهنمای ساخت APK
└── README.md
```

## چگونه به APK تبدیل کنیم؟

ساخت APK واقعی نیاز به Android Studio یا Capacitor دارد. دو روش ساده:

### روش ۱ — Capacitor (پیشنهادی و سریع)

1. Node.js نصب کنید.
2. در پوشه پروژه این دستورات را اجرا کنید:

```bash
npm init -y
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "DeltaNG" "com.deltang.vpn" --web-dir=www
npx cap add android
npx cap sync
npx cap open android
```

3. در Android Studio روی **Build → Build Bundle(s) / APK(s) → Build APK(s)** کلیک کنید.

### روش ۲ — WebView ساده در Android Studio

1. یک پروژه Empty Activity جدید بسازید.
2. فایل `index.html` را داخل پوشه `assets` قرار دهید.
3. در `MainActivity` یک WebView بسازید و فایل را لود کنید (`file:///android_asset/index.html`).
4. مجوزهای اینترنت و `usesCleartextTraffic` را در Manifest اضافه کنید.
5. APK را بیلد بگیرید.

### روش ۳ — ابزارهای آنلاین / PWA Builder

می‌توانید فایل `www/index.html` را به عنوان Progressive Web App بسته‌بندی کنید یا از سرویس‌هایی مثل PWA Builder استفاده کنید.

---

**توجه:** این فقط رابط کاربری (UI) است. برای اتصال واقعی به سرورهای VLESS/Reality نیاز به هسته VPN (مثل Xray / sing-box) و کد نیتیو اندروید دارید.
