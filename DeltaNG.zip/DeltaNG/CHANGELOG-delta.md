# Delta NG 1.2.0

## Complete ready-to-build client
- Vendored official `libv2ray.aar` (Xray core) under `V2rayNG/app/libs/`
- Bundled `geoip.dat` + `geosite.dat` in assets (routing/Iran rules work offline)
- CI prefers vendored AAR; falls back to GitHub latest download
- applicationId `com.deltang.vpn` · versionName `1.2.0-delta` · versionCode 780
- Delta Web UI + native advanced settings unchanged structure

## Not merged from protected APK
- `libfuck.so` / NP protector / obfuscated DEX — not source, not injectable
