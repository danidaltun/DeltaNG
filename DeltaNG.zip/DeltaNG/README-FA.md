# Delta NG ۱.۲.۰ — کلاینت کامل آماده بیلد

- هسته Xray داخل `V2rayNG/app/libs/libv2ray.aar`
- geoip/geosite داخل assets
- بیلد گیت‌هاب: `BUILD_GITHUB.md`

# Delta NG (بر پایه v2rayNG + هسته Xray)

## ساخت APK (یکی از دو راه)
1. **گیت‌هاب (بدون نصب چیزی):** پوشه را در یک repo بگذار و push کن → تب Actions → `Build DeltaNG APK` → خروجی `DeltaNG-APK`.
2. **لوکال:** JDK 21 + Android SDK 37 + NDK 30.0.16248370 → `ANDROID_HOME=... ./build.sh`

بیلد خودش `libv2ray.aar` (هسته Xray) و تانل hev را دانلود/کامپایل می‌کند (نیاز به اینترنت).

## سرور Xray
روی VPS اوبونتو/دبیان: `bash server/install-xray.sh 443 www.microsoft.com`
خروجی: لینک `vless://` (Reality + Vision) → داخل اپ Paste کن.

## تغییرات ۱.۰.۱ (دیباگ / بهینه‌سازی)
- WebView قفل‌شده روی `file:///android_asset/delta/` (بدون ناوبری بیرونی)
- import لینک با سقف حجم برای جلوگیری از کرش
- onPing بدون NPE وقتی سرور از لیست حذف شده
- پیش‌فرض Flow فرم دستی: `xtls-rprx-vision` (استاندارد Reality ایران)
- روتینگ Bypass ایران غنی‌تر (بانک/اسنپ/دیجیکالا/اپراتور/ویدیو)
- نام APK خروجی: `DeltaNG_*`

## قابلیت‌ها
- هسته واقعی Xray، حالت VPN (TUN با hev-socks5-tunnel) و Proxy-only و Root
- VLESS / VMess / Trojan / Shadowsocks / Hysteria2 / WireGuard / SOCKS / HTTP
- Reality، XHTTP، gRPC، WS، TCP، KCP، QUIC
- اشتراک (Subscription) با آپدیت خودکار + نمایش حجم مصرفی
- پینگ واقعی (تست از طریق هسته) و تست گروهی
- مسیریابی: Global / Bypass ایران / روسیه / Whitelist / Blacklist + geo قابل‌آپدیت
- Per-app proxy، Proxy Chain، Server Group (بالانسر)
- اسکن QR، ورود از کلیپ‌بورد، بکاپ/ریستور محلی و WebDAV
- ویجت، Quick Tile، میانبر، Tasker، اجرا هنگام بوت
- تم تیره نئونی، فارسی/RTL، منبع‌باز GPL-3.0

## معماری ادغام
- UI دلتا: `V2rayNG/app/src/main/assets/delta/index.html` (تک‌فایل، بدون وابستگی خارجی)
- پل: `ui/delta/DeltaActivity.kt` — اتصال/قطع، لیست سرور، ایمپورت لینک و اشتراک، پینگ واقعی، تنظیمات، همه از طریق همان Managerهای DeltaNG
- لانچر اصلی اپ حالا DeltaActivity است؛ «تنظیمات پیشرفته» همان UI کامل DeltaNG را باز می‌کند
- `extras/delta-ui-mock`: ماکت قدیمی، فقط مرجع
- سرعت لحظه‌ای RX/TX نمایش داده نمی‌شود (به‌جاش پینگ و پروتکل)

## مدیریت سرور (داخل UI دلتا)
- افزودن: با لینک/اشتراک (چندتا با هم) یا **فرم دستی** (VLESS / VMess / Trojan / Shadowsocks، با Reality/TLS و WS/gRPC/xhttp)
- حذف تک‌سرور، **حذف تکراری‌ها**، **حذف ناموفق‌ها** (بعد از تست پینگ)
- تست پینگ: همه سرورها یا فقط یک سرور (لمس برچسب پینگ)
- مرتب‌سازی: پیش‌فرض / کمترین پینگ / نام / پروتکل / جدیدترین

## مجوز
GPL-3.0-or-later — فایل `NOTICE.md`
