# Delta NG — License & Credits

Source code of this project is licensed under **GPL-3.0-or-later** (see `LICENSE`).
No ads, no analytics, no trackers, no proprietary SDKs. The UI is a single local HTML file; nothing is loaded from the internet.

Built on open-source components (check each upstream for its exact license):
- v2rayNG / DeltaNG (GPL-3.0) — Android client
- Xray-core via AndroidLibXrayLite — proxy core
- hev-socks5-tunnel — TUN to SOCKS5
- AndroidX, Jetpack Compose, OkHttp, Gson, MMKV, ZXing — see `V2rayNG/app/src/main/assets/open_source_licenses.html`
