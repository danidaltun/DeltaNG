#!/usr/bin/env bash
# Xray VLESS + Reality server installer (Debian/Ubuntu, run as root).
# Usage: bash install-xray.sh [port=443] [sni=www.microsoft.com]
set -euo pipefail
PORT="${1:-443}"; SNI="${2:-www.microsoft.com}"
[ "$(id -u)" = 0 ] || { echo "run as root"; exit 1; }
apt-get update -y >/dev/null && apt-get install -y curl unzip openssl >/dev/null
bash -c "$(curl -fsSL https://github.com/XTLS/Xray-install/raw/main/install-release.sh)" @ install
UUID=$(xray uuid)
KEYS=$(xray x25519)
PRIV=$(echo "$KEYS" | awk '/Private/{print $NF}')
PUB=$(echo "$KEYS" | awk '/Public|Password/{print $NF}' | tail -1)
SID=$(openssl rand -hex 8)
cat > /usr/local/etc/xray/config.json <<EOF
{
  "log": {"loglevel": "warning"},
  "inbounds": [{
    "port": $PORT, "protocol": "vless",
    "settings": {"clients": [{"id": "$UUID", "flow": "xtls-rprx-vision"}], "decryption": "none"},
    "streamSettings": {
      "network": "tcp", "security": "reality",
      "realitySettings": {
        "dest": "$SNI:443", "serverNames": ["$SNI"],
        "privateKey": "$PRIV", "shortIds": ["$SID"]
      }
    },
    "sniffing": {"enabled": true, "destOverride": ["http","tls","quic"]}
  }],
  "outbounds": [{"protocol": "freedom"}]
}
EOF
systemctl enable xray >/dev/null 2>&1; systemctl restart xray
IP=$(curl -fs https://api.ipify.org || echo YOUR_IP)
LINK="vless://$UUID@$IP:$PORT?encryption=none&flow=xtls-rprx-vision&security=reality&sni=$SNI&fp=chrome&pbk=$PUB&sid=$SID&type=tcp#DeltaNG-$IP"
echo; echo "=== لینک را در کلاینت وارد کنید ==="; echo "$LINK"
echo "$LINK" > /root/delta-link.txt
