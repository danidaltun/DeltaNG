# Delta NG — سورس کامل آماده بیلد

## محتویات بسته‌بندی‌شده
| جزء | مسیر | توضیح |
|-----|------|--------|
| هسته Xray | `V2rayNG/app/libs/libv2ray.aar` | رسمی 2dust/AndroidLibXrayLite (آخرین) |
| GeoIP / GeoSite | `V2rayNG/app/src/main/assets/geoip.dat` + `geosite.dat` | از کلاینت مرجع + قابل آپدیت |
| UI دلتا | `assets/delta/index.html` + `DeltaActivity` | تم نئون |
| TUN | بیلد از `hev-socks5-tunnel` در CI / `compile-hevtun.sh` |
| Workflow | `.github/workflows/build.yml` | بیلد یک‌کلیکه Actions |

## گیت‌هاب (بدون نصب SDK)
1. این پوشه را `git push` به repo خودت
2. Actions → **Build DeltaNG APK** → Run workflow
3. Artifact: `DeltaNG-APK`

اگر `libv2ray.aar` داخل repo باشد، CI همان را می‌گیرد (بدون دانلود اجباری).

## لوکال
```bash
export ANDROID_HOME=...
./build.sh
```

## نکته درباره v2rayy.zip
آن فایل یک **APK محافظت‌شده** بود (`libfuck.so` / PairIP)، نه سورس.
از آن فقط `geoip.dat` و `geosite.dat` استخراج و تزریق شد.
کد DEX محافظت‌شده قابل ادغام قانونی/فنی در سورس نیست — هسته رسمی Xray جایگزین صحیح است.
