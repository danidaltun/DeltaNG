package com.v2ray.ang.ui.compose

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.v2ray.ang.AppConfig
import com.v2ray.ang.handler.MmkvManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Delta NG visual system — neon glass / cyber cyan
 * Inspired by Delta NG concept UI (deep navy + electric cyan + signal green)
 */

// Brand tokens
private val DeltaCyan = Color(0xFFF59E0B)
private val DeltaCyanDim = Color(0xFFD97706)
private val DeltaCyanSoft = Color(0xFF4DFFFFFF)
private val DeltaGreen = Color(0xFF10B981)
private val DeltaGreenDim = Color(0xFF059669)
private val DeltaNavy = Color(0xFF050609)
private val DeltaNavyCard = Color(0xFF0E1118)
private val DeltaNavyElevated = Color(0xFF171C27)
private val DeltaOutline = Color(0xFFF59E0B)
private val DeltaText = Color(0xFFF8FAFC)
private val DeltaTextMuted = Color(0xFF94A3B8)

private val LightColor = lightColorScheme(
    primary = Color(0xFF006B7D),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFA8EFFF),
    onPrimaryContainer = Color(0xFF001F26),
    secondary = Color(0xFF006D45),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFF8FF8C2),
    onSecondaryContainer = Color(0xFF002113),
    tertiary = Color(0xFF005DB2),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFD0E4FF),
    onTertiaryContainer = Color(0xFF001D36),
    error = Color(0xFFBA1A1A),
    errorContainer = Color(0xFFFFDAD6),
    onError = Color(0xFFFFFFFF),
    onErrorContainer = Color(0xFF410002),
    background = Color(0xFFF4FAFF),
    onBackground = Color(0xFF0E1118),
    surface = Color(0xFFF4FAFF),
    onSurface = Color(0xFF0E1118),
    surfaceVariant = Color(0xFFD5E8F5),
    onSurfaceVariant = Color(0xFF3A4D5C),
    outline = Color(0xFF6A8090),
    outlineVariant = Color(0xFFB9C9D6),
    inverseSurface = Color(0xFF0E1118),
    inverseOnSurface = Color(0xFFF8FAFC),
    inversePrimary = DeltaCyan,
    surfaceTint = Color(0xFF006B7D),
    scrim = Color(0xFF000000),
)

private val DarkColor = darkColorScheme(
    // Electric cyan primary — matches neon frames in concept
    primary = DeltaCyan,
    onPrimary = Color(0xFF003640),
    primaryContainer = Color(0xFF004E5C),
    onPrimaryContainer = Color(0xFFA8EFFF),
    // Signal green secondary — Connected / latency chips
    secondary = DeltaGreen,
    onSecondary = Color(0xFF00391F),
    secondaryContainer = Color(0xFF005230),
    onSecondaryContainer = Color(0xFF8FF8C2),
    // Deep blue tertiary
    tertiary = Color(0xFF7CB8FF),
    onTertiary = Color(0xFF00315E),
    tertiaryContainer = Color(0xFF004A85),
    onTertiaryContainer = Color(0xFFD0E4FF),
    error = Color(0xFFFFB4AB),
    errorContainer = Color(0xFF93000A),
    onError = Color(0xFF690005),
    onErrorContainer = Color(0xFFFFDAD6),
    // Deep navy glass background
    background = DeltaNavy,
    onBackground = DeltaText,
    surface = DeltaNavyCard,
    onSurface = DeltaText,
    surfaceVariant = DeltaNavyElevated,
    onSurfaceVariant = DeltaTextMuted,
    outline = Color(0xFF3D6A8A),
    outlineVariant = Color(0xFF1A3A5C),
    inverseSurface = Color(0xFFF8FAFC),
    inverseOnSurface = Color(0xFF0E1118),
    inversePrimary = Color(0xFF006B7D),
    surfaceTint = DeltaCyan,
    scrim = Color(0xFF000000),
)

object ThemeManager {
    // Default dark (2) so Delta neon theme is the first impression
    private val _themeMode = MutableStateFlow(
        MmkvManager.decodeSettingsString(AppConfig.PREF_UI_MODE_NIGHT, "2") ?: "2"
    )
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()

    // Dynamic Material You OFF by default — keep Delta brand colors
    private val _dynamicColorEnabled = MutableStateFlow(
        MmkvManager.decodeSettingsBool(AppConfig.PREF_DYNAMIC_COLOR, false)
    )
    val dynamicColorEnabled: StateFlow<Boolean> = _dynamicColorEnabled.asStateFlow()

    fun setThemeMode(mode: String) {
        MmkvManager.encodeSettings(AppConfig.PREF_UI_MODE_NIGHT, mode)
        _themeMode.value = mode
    }

    fun setDynamicColorEnabled(enabled: Boolean) {
        MmkvManager.encodeSettings(AppConfig.PREF_DYNAMIC_COLOR, enabled)
        _dynamicColorEnabled.value = enabled
    }

    fun refresh() {
        _themeMode.value =
            MmkvManager.decodeSettingsString(AppConfig.PREF_UI_MODE_NIGHT, "2") ?: "2"
        _dynamicColorEnabled.value =
            MmkvManager.decodeSettingsBool(AppConfig.PREF_DYNAMIC_COLOR, false)
    }
}

@Composable
fun resolveDarkTheme(): Boolean {
    val mode by ThemeManager.themeMode.collectAsState()
    return when (mode) {
        "1" -> false
        "2" -> true
        else -> isSystemInDarkTheme()
    }
}

val LocalDarkTheme = compositionLocalOf { false }

@Composable
fun AppTheme(
    darkTheme: Boolean = resolveDarkTheme(),
    content: @Composable () -> Unit
) {
    val dynamicColor by ThemeManager.dynamicColorEnabled.collectAsState()
    val context = LocalContext.current
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColor
        else -> LightColor
    }
    val snackbarController = rememberAppSnackbarController()

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val activity = view.context as? Activity ?: return@SideEffect
            val window = activity.window
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !darkTheme
                isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    CompositionLocalProvider(
        LocalDarkTheme provides darkTheme,
        LocalAppSnackbar provides snackbarController
    ) {
        MaterialTheme(
            colorScheme = colorScheme
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                AppSnackbarBridge(controller = snackbarController)
                content()
                AppSnackbarHost(hostState = snackbarController.hostState)
            }
        }
    }
}
