// SPDX-License-Identifier: GPL-3.0-or-later
package com.v2ray.ang.ui.delta

import android.Manifest
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.v2ray.ang.AppConfig
import com.v2ray.ang.core.LauncherManager
import com.v2ray.ang.dto.RealPingResult
import com.v2ray.ang.dto.entities.ProfileItem
import com.v2ray.ang.extension.isComplexType
import com.v2ray.ang.dto.TestServiceMessage
import com.v2ray.ang.enums.RoutingType
import com.v2ray.ang.extension.serializable
import com.v2ray.ang.handler.AngConfigManager
import com.v2ray.ang.handler.MmkvManager
import com.v2ray.ang.handler.SettingsManager
import com.v2ray.ang.helper.MessageHelper
import com.v2ray.ang.ui.main.MainActivity
import com.v2ray.ang.util.Utils
import org.json.JSONArray
import org.json.JSONObject

/**
 * DeltaNG UI (WebView) running on top of the real DeltaNG / Xray core.
 * All connect / ping / import operations go through the same managers the native UI uses.
 */
class DeltaActivity : ComponentActivity() {

    private lateinit var web: WebView
    private var pendingGuid: String? = null

    private val vpnPermission = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val guid = pendingGuid
        pendingGuid = null
        if (result.resultCode == RESULT_OK && guid != null) {
            LauncherManager.startService(this, guid)
        } else {
            js("KB.onState('failed','دسترسی VPN داده نشد')")
        }
    }

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val i = intent ?: return
            when (i.getIntExtra("key", 0)) {
                AppConfig.MSG_STATE_RUNNING,
                AppConfig.MSG_STATE_START_SUCCESS -> js("KB.onState('running')")
                AppConfig.MSG_STATE_NOT_RUNNING,
                AppConfig.MSG_STATE_STOP_SUCCESS -> js("KB.onState('stopped')")
                AppConfig.MSG_STATE_START_FAILURE -> {
                    val msg = JSONObject.quote(i.getStringExtra("content").orEmpty())
                    js("KB.onState('failed',$msg)")
                }
                AppConfig.MSG_MEASURE_CONFIG_SUCCESS -> {
                    val r = i.serializable<RealPingResult>("content") ?: return
                    js("KB.onPing(${JSONObject.quote(r.guid)},${r.delayMillis})")
                }
                AppConfig.MSG_MEASURE_CONFIG_FINISH,
                AppConfig.MSG_MEASURE_CONFIG_CANCEL -> js("KB.onPingDone()")
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Make sure routing presets / geo assets exist exactly like the native UI does on first run.
        Thread { runCatching { SettingsManager.initAssets(applicationContext, applicationContext.assets) } }.start()

        web = WebView(this).apply {
            // Local single-file UI only — keep JS on, lock down remote/file risks.
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.allowFileAccessFromFileURLs = false
            settings.allowUniversalAccessFromFileURLs = false
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
            settings.setSupportZoom(false)
            settings.builtInZoomControls = false
            settings.displayZoomControls = false
            settings.mediaPlaybackRequiresUserGesture = true
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                settings.safeBrowsingEnabled = true
            }
            setBackgroundColor(0xFF050609.toInt())
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: android.webkit.WebResourceRequest?
                ): Boolean {
                    // Block any navigation away from the bundled asset UI.
                    val url = request?.url?.toString().orEmpty()
                    return !(url.startsWith("file:///android_asset/delta/"))
                }
            }
            addJavascriptInterface(Bridge(), "Android")
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/delta/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("KB.back()") { r ->
                    if (r != "true") {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })

        ContextCompat.registerReceiver(
            this, receiver, IntentFilter(AppConfig.BROADCAST_ACTION_ACTIVITY), Utils.receiverFlags()
        )
        MessageHelper.sendMsg2Service(this, AppConfig.MSG_REGISTER_CLIENT, "")
    }

    override fun onResume() {
        super.onResume()
        MessageHelper.sendMsg2Service(this, AppConfig.MSG_REGISTER_CLIENT, "")
        js("window.KB&&KB.refresh()")
    }

    override fun onDestroy() {
        runCatching { MessageHelper.sendMsg2Service(this, AppConfig.MSG_UNREGISTER_CLIENT, "") }
        runCatching { unregisterReceiver(receiver) }
        web.removeJavascriptInterface("Android")
        web.destroy()
        super.onDestroy()
    }

    private fun js(code: String) {
        if (!::web.isInitialized) return
        web.post { web.evaluateJavascript("try{$code}catch(e){}", null) }
    }

    private fun beginConnect(guid: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        MmkvManager.setSelectServer(guid)
        if (!SettingsManager.isVpnMode()) {
            LauncherManager.startService(this, guid)
            return
        }
        val prepare = VpnService.prepare(this)
        if (prepare == null) {
            LauncherManager.startService(this, guid)
        } else {
            pendingGuid = guid
            vpnPermission.launch(prepare)
        }
    }

    inner class Bridge {

        @JavascriptInterface
        fun ready() {
            MessageHelper.sendMsg2Service(this@DeltaActivity, AppConfig.MSG_REGISTER_CLIENT, "")
        }

        @JavascriptInterface
        fun getServers(): String {
            val arr = JSONArray()
            for (guid in MmkvManager.decodeAllServerList()) {
                val p = MmkvManager.decodeServerConfig(guid) ?: continue
                val delay = MmkvManager.decodeServerAffiliationInfo(guid)?.testDelayMillis ?: 0L
                val net = p.network?.takeIf { it.isNotEmpty() } ?: "tcp"
                val sec = p.security?.takeIf { it.isNotEmpty() } ?: "none"
                arr.put(JSONObject().apply {
                    put("id", guid)
                    put("name", p.remarks.ifEmpty { "${p.server}:${p.serverPort}" })
                    put("type", p.configType.name)
                    put("proto", "${p.configType.name} • $net/$sec")
                    put("ping", delay)
                    put("added", p.addedTime)
                })
            }
            return JSONObject().apply {
                put("servers", arr)
                put("selected", MmkvManager.getSelectServer().orEmpty())
            }.toString()
        }

        @JavascriptInterface
        fun importLinks(text: String): Int = try {
            val cleaned = text.trim().take(2_000_000) // hard cap: protect MMKV / parser
            if (cleaned.isEmpty()) return 0
            val (count, countSub) = AngConfigManager.importBatchConfig(cleaned, "", false)
            count + countSub
        } catch (e: Exception) {
            0
        }

        @JavascriptInterface
        fun clipboard(): String = try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.primaryClip?.getItemAt(0)?.coerceToText(this@DeltaActivity)?.toString().orEmpty()
        } catch (e: Exception) {
            ""
        }

        @JavascriptInterface
        fun select(guid: String) {
            MmkvManager.setSelectServer(guid)
        }

        @JavascriptInterface
        fun remove(guid: String) {
            MmkvManager.removeServer(guid)
        }

        @JavascriptInterface
        fun connect(guid: String) {
            runOnUiThread { beginConnect(guid) }
        }

        @JavascriptInterface
        fun disconnect() {
            runOnUiThread { LauncherManager.stopService(this@DeltaActivity) }
        }

        @JavascriptInterface
        fun pingAll() {
            val guids = MmkvManager.decodeAllServerList()
            MessageHelper.sendMsg2TestService(
                this@DeltaActivity,
                TestServiceMessage(
                    key = AppConfig.MSG_MEASURE_CONFIG_START,
                    subscriptionId = "",
                    serverGuids = guids,
                    onlyTcp = false
                )
            )
        }

        @JavascriptInterface
        fun pingOne(guid: String) {
            MessageHelper.sendMsg2TestService(
                this@DeltaActivity,
                TestServiceMessage(
                    key = AppConfig.MSG_MEASURE_CONFIG_START,
                    serverGuids = listOf(guid),
                    onlyTcp = false
                )
            )
        }

        /** Removes servers whose connection parameters are identical; keeps the selected one first. */
        @JavascriptInterface
        fun dedupe(): Int = try {
            val selected = MmkvManager.getSelectServer()
            val ordered = MmkvManager.decodeAllServerList().sortedBy { if (it == selected) 0 else 1 }
            val seen = HashSet<ProfileItem>()
            val dups = ArrayList<String>()
            for (guid in ordered) {
                val p = MmkvManager.decodeServerConfig(guid) ?: continue
                if (p.configType.isComplexType()) continue
                if (!seen.add(p.duplicateIdentity())) dups += guid
            }
            dups.forEach { MmkvManager.removeServer(it) }
            dups.size
        } catch (e: Exception) {
            0
        }

        /** Removes servers whose last real-ping test failed (negative delay). Never removes the selected one. */
        @JavascriptInterface
        fun removeDead(): Int = try {
            val selected = MmkvManager.getSelectServer()
            val dead = MmkvManager.decodeAllServerList().filter { guid ->
                guid != selected &&
                    (MmkvManager.decodeServerAffiliationInfo(guid)?.testDelayMillis ?: 0L) < 0L
            }
            dead.forEach { MmkvManager.removeServer(it) }
            dead.size
        } catch (e: Exception) {
            0
        }

        @JavascriptInterface
        fun getSettings(): String = JSONObject().apply {
            put("fragment", MmkvManager.decodeSettingsBool(AppConfig.PREF_FRAGMENT_ENABLED, false))
            put("mux", MmkvManager.decodeSettingsBool(AppConfig.PREF_MUX_ENABLED, false))
            put("hevTun", MmkvManager.decodeSettingsBool(AppConfig.PREF_USE_HEV_TUNNEL, true))
            put("iranRouting", MmkvManager.decodeSettingsBool(DL_IRAN_FLAG, false))
        }.toString()

        @JavascriptInterface
        fun setSetting(key: String, value: Boolean) {
            when (key) {
                "fragment" -> MmkvManager.encodeSettings(AppConfig.PREF_FRAGMENT_ENABLED, value)
                "mux" -> MmkvManager.encodeSettings(AppConfig.PREF_MUX_ENABLED, value)
                "hevTun" -> MmkvManager.encodeSettings(AppConfig.PREF_USE_HEV_TUNNEL, value)
                "iranRouting" -> {
                    MmkvManager.encodeSettings(DL_IRAN_FLAG, value)
                    SettingsManager.resetRoutingRulesetsFromPresets(
                        this@DeltaActivity,
                        if (value) RoutingType.WHITE_IRAN else RoutingType.GLOBAL
                    )
                }
                else -> return
            }
            // Only restarts if a daemon is already running; never starts a stopped one.
            LauncherManager.restartService(this@DeltaActivity)
        }

        @JavascriptInterface
        fun updateSubs() {
            Thread {
                runCatching { AngConfigManager.updateConfigViaSubAll() }
                js("KB.refresh();KB.toast('اشتراک‌ها آپدیت شد')")
            }.start()
        }

        @JavascriptInterface
        fun openAdvanced() {
            runOnUiThread { startActivity(Intent(this@DeltaActivity, MainActivity::class.java)) }
        }
    }

    private companion object {
        const val DL_IRAN_FLAG = "delta_iran_routing"
    }
}
