#!/usr/bin/env bash
# Local build (Linux/macOS). Needs: JDK 21, Android SDK (platform 37, build-tools 37), NDK 30.0.16248370, git, internet.
set -euo pipefail
cd "$(dirname "$0")"
: "${ANDROID_HOME:?set ANDROID_HOME}"; : "${NDK_HOME:=$ANDROID_HOME/ndk/30.0.16248370}"; export NDK_HOME
rm -rf hev-socks5-tunnel && git clone --recursive --depth 1 https://github.com/heiher/hev-socks5-tunnel
bash compile-hevtun.sh && cp -r libs V2rayNG/app/
mkdir -p V2rayNG/app/libs
if [ -f V2rayNG/app/libs/libv2ray.aar ]; then echo "vendored libv2ray.aar"; else
curl -fL "https://github.com/2dust/AndroidLibXrayLite/releases/latest/download/libv2ray.aar" -o V2rayNG/app/libs/libv2ray.aar
fi
[ -f delta.jks ] || keytool -genkeypair -keystore delta.jks -storepass deltang123 -keypass deltang123 -alias delta -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=DeltaNG"
cd V2rayNG; echo "sdk.dir=$ANDROID_HOME" > local.properties; chmod +x gradlew
./gradlew assembleRelease -Pandroid.injected.signing.store.file="$PWD/../delta.jks" -Pandroid.injected.signing.store.password=deltang123 -Pandroid.injected.signing.key.alias=delta -Pandroid.injected.signing.key.password=deltang123
echo "APK: $(ls app/build/outputs/apk/*/release/*.apk)"
